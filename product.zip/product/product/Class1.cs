﻿namespace product
{
    public class Class1
    {

    }
}
